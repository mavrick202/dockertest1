# 🎭 Fake User Generator — AWS Serverless App

A fully serverless application that generates random user profiles and stores them in DynamoDB.

## Architecture

```
Browser
  │
  ├── Static files ──► S3 Bucket (Website Hosting)
  │
  └── API calls ──────► API Gateway (REST)
                              │
                              ▼
                         Lambda (Python 3.12)
                              │
                              ▼
                         DynamoDB Table
                         (UserProfiles)
```

## AWS Resources

| Resource | Name | Purpose |
|----------|------|---------|
| S3 Bucket | `<your-bucket>` | Hosts `index.html` (static frontend) |
| API Gateway | `FakeUserGateway` | REST API with `/users` routes |
| Lambda | `FakeUserAPI` | Python handler — CRUD on DynamoDB |
| DynamoDB | `UserProfiles` | Stores generated user records |
| IAM Role | `FakeUserLambdaRole` | Lambda execution role |

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/users` | Save a generated user |
| `GET` | `/users` | List all saved users |
| `DELETE` | `/users/{userId}` | Delete a user |

## Project Structure

```
aws-serverless-app/
├── frontend/
│   └── index.html          # Single-page app (Vanilla JS, no build step)
├── backend/
│   └── lambda_function.py  # Python Lambda handler
└── infrastructure/
    └── deploy.py           # One-shot deployment & teardown script
```

## Prerequisites

- Python 3.8+
- AWS CLI configured (`aws configure`)
- `boto3` installed

```bash
pip install boto3
```

## Deploy

```bash
cd infrastructure
python deploy.py --region us-east-1 --bucket my-fake-user-app-2024
```

> ⚠️  S3 bucket names must be **globally unique**. Choose a name that's unlikely to exist.

The script will output:
```
  Frontend : http://my-fake-user-app-2024.s3-website-us-east-1.amazonaws.com
  API Base : https://xxxxxxxx.execute-api.us-east-1.amazonaws.com/prod
```

Open the Frontend URL in your browser — done!

## Tear Down (avoid AWS charges)

```bash
python deploy.py --destroy --region us-east-1 --bucket my-fake-user-app-2024
```

## DynamoDB Schema

Each item in the `UserProfiles` table:

```json
{
  "userId":    "uuid-v4",
  "createdAt": "2024-01-15T10:30:00.000Z",
  "firstName": "Emma",
  "lastName":  "Johnson",
  "email":     "emmajohnson42@gmail.com",
  "phone":     "+1 (555) 867-5309",
  "address":   "1234 Maple St",
  "city":      "Austin",
  "state":     "TX",
  "zipCode":   "78701",
  "country":   "United States",
  "company":   "Acme Corp",
  "jobTitle":  "Software Engineer",
  "username":  "emmajohnson42",
  "website":   "https://emmajohnson42.dev",
  "bio":       "Coffee addict. Code enthusiast.",
  "age":       28,
  "gender":    "Female"
}
```

## How It Works

1. User clicks **Generate User** → JavaScript generates a fake profile (no API call)
2. User clicks **Save to DynamoDB** → `POST /users` → Lambda writes to DynamoDB
3. Table auto-refreshes → `GET /users` → Lambda scans DynamoDB → renders table
4. Delete button → `DELETE /users/{id}` → Lambda removes the item
