#!/usr/bin/env python3
"""
deploy.py – One-shot deployment script for the Fake-User Generator app.

Resources created:
  • DynamoDB table  : UserProfiles
  • IAM role        : FakeUserLambdaRole
  • Lambda function : FakeUserAPI
  • API Gateway     : FakeUserGateway  (REST, /users)
  • S3 bucket       : <bucket-name>    (static website hosting)

Usage:
  pip install boto3
  python deploy.py --region us-east-1 --bucket my-fake-user-app-2024

Tear-down:
  python deploy.py --destroy --region us-east-1 --bucket my-fake-user-app-2024
"""

import argparse
import boto3
import json
import os
import sys
import time
import zipfile
import io

# ── helpers ────────────────────────────────────────────────────────────────────

def step(msg): print(f"\n{'='*60}\n  {msg}\n{'='*60}")
def ok(msg):   print(f"  ✔  {msg}")
def info(msg): print(f"     {msg}")

def zip_lambda(src_path: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(src_path, 'lambda_function.py')
    return buf.getvalue()


# ── deploy ──────────────────────────────────────────────────────────────────────

def deploy(region: str, bucket: str):
    session = boto3.Session(region_name=region)
    iam     = session.client('iam')
    lmb     = session.client('lambda')
    apigw   = session.client('apigateway')
    ddb     = session.client('dynamodb')
    s3      = session.client('s3')
    sts     = session.client('sts')

    account_id = sts.get_caller_identity()['Account']

    # 1. DynamoDB ---------------------------------------------------------------
    step("1 / 5  Creating DynamoDB table")
    try:
        ddb.create_table(
            TableName='UserProfiles',
            KeySchema=[{'AttributeName': 'userId', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'userId', 'AttributeType': 'S'}],
            BillingMode='PAY_PER_REQUEST',
        )
        waiter = ddb.get_waiter('table_exists')
        waiter.wait(TableName='UserProfiles')
        ok("Table 'UserProfiles' created")
    except ddb.exceptions.ResourceInUseException:
        ok("Table 'UserProfiles' already exists – skipping")

    # 2. IAM role ---------------------------------------------------------------
    step("2 / 5  Creating IAM role")
    trust = json.dumps({
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "lambda.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    })
    try:
        role = iam.create_role(RoleName='FakeUserLambdaRole', AssumeRolePolicyDocument=trust)
        role_arn = role['Role']['Arn']
        iam.attach_role_policy(RoleName='FakeUserLambdaRole',
            PolicyArn='arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole')
        iam.attach_role_policy(RoleName='FakeUserLambdaRole',
            PolicyArn='arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess')
        ok(f"Role created: {role_arn}")
        info("Waiting 15 s for IAM propagation …")
        time.sleep(15)
    except iam.exceptions.EntityAlreadyExistsException:
        role_arn = iam.get_role(RoleName='FakeUserLambdaRole')['Role']['Arn']
        ok(f"Role already exists: {role_arn}")

    # 3. Lambda -----------------------------------------------------------------
    step("3 / 5  Deploying Lambda function")
    zip_bytes = zip_lambda(os.path.join(os.path.dirname(__file__), 'lambda_function.py'))
    try:
        fn = lmb.create_function(
            FunctionName='FakeUserAPI',
            Runtime='python3.12',
            Role=role_arn,
            Handler='lambda_function.lambda_handler',
            Code={'ZipFile': zip_bytes},
            Timeout=30,
            MemorySize=256,
            Environment={'Variables': {}},
        )
        fn_arn = fn['FunctionArn']
        ok(f"Lambda created: {fn_arn}")
    except lmb.exceptions.ResourceConflictException:
        lmb.update_function_code(FunctionName='FakeUserAPI', ZipFile=zip_bytes)
        fn_arn = lmb.get_function(FunctionName='FakeUserAPI')['Configuration']['FunctionArn']
        ok(f"Lambda updated: {fn_arn}")

    # 4. API Gateway ------------------------------------------------------------
    step("4 / 5  Creating API Gateway")
    apis = apigw.get_rest_apis()['items']
    api  = next((a for a in apis if a['name'] == 'FakeUserGateway'), None)

    if api is None:
        api = apigw.create_rest_api(
            name='FakeUserGateway',
            endpointConfiguration={'types': ['REGIONAL']}
        )
        ok(f"API created: {api['id']}")
    else:
        ok(f"API already exists: {api['id']}")

    api_id    = api['id']
    root_id   = apigw.get_resources(restApiId=api_id)['items'][0]['id']

    def ensure_resource(parent_id, path_part):
        resources = apigw.get_resources(restApiId=api_id)['items']
        existing  = next((r for r in resources if r.get('pathPart') == path_part
                          and r.get('parentId') == parent_id), None)
        if existing:
            return existing['id']
        return apigw.create_resource(restApiId=api_id, parentId=parent_id,
                                     pathPart=path_part)['id']

    def ensure_method(resource_id, http_method):
        try:
            apigw.put_method(restApiId=api_id, resourceId=resource_id,
                             httpMethod=http_method, authorizationType='NONE')
        except apigw.exceptions.ConflictException:
            pass

    def put_lambda_integration(resource_id, http_method):
        uri = (f"arn:aws:apigateway:{region}:lambda:path/2015-03-31"
               f"/functions/{fn_arn}/invocations")
        try:
            apigw.put_integration(restApiId=api_id, resourceId=resource_id,
                                  httpMethod=http_method, type='AWS_PROXY',
                                  integrationHttpMethod='POST', uri=uri)
        except apigw.exceptions.ConflictException:
            pass

    # /users
    users_id = ensure_resource(root_id, 'users')
    for m in ('GET', 'POST', 'OPTIONS'):
        ensure_method(users_id, m)
        put_lambda_integration(users_id, m)

    # /users/{userId}
    uid_id = ensure_resource(users_id, '{userId}')
    for m in ('DELETE', 'OPTIONS'):
        ensure_method(uid_id, m)
        put_lambda_integration(uid_id, m)

    # Lambda permission
    try:
        lmb.add_permission(FunctionName='FakeUserAPI', StatementId='ApiGatewayInvoke',
                           Action='lambda:InvokeFunction', Principal='apigateway.amazonaws.com',
                           SourceArn=f"arn:aws:execute-api:{region}:{account_id}:{api_id}/*/*")
    except lmb.exceptions.ResourceConflictException:
        pass

    # Deploy stage
    apigw.create_deployment(restApiId=api_id, stageName='prod')
    api_url = f"https://{api_id}.execute-api.{region}.amazonaws.com/prod"
    ok(f"API deployed: {api_url}")

    # 5. S3 static website ------------------------------------------------------
    step("5 / 5  Creating S3 bucket + uploading frontend")
    try:
        if region == 'us-east-1':
            s3.create_bucket(Bucket=bucket)
        else:
            s3.create_bucket(Bucket=bucket,
                             CreateBucketConfiguration={'LocationConstraint': region})
        ok(f"Bucket '{bucket}' created")
    except s3.exceptions.BucketAlreadyOwnedByYou:
        ok(f"Bucket '{bucket}' already exists – reusing")

    # Public access
    s3.delete_public_access_block(Bucket=bucket)
    s3.put_bucket_policy(Bucket=bucket, Policy=json.dumps({
        "Version": "2012-10-17",
        "Statement": [{
            "Sid": "PublicRead",
            "Effect": "Allow",
            "Principal": "*",
            "Action": "s3:GetObject",
            "Resource": f"arn:aws:s3:::{bucket}/*"
        }]
    }))
    s3.put_bucket_website(Bucket=bucket, WebsiteConfiguration={
        'IndexDocument': {'Suffix': 'index.html'},
        'ErrorDocument': {'Key': 'index.html'}
    })

    # Inject API URL into the HTML and upload
    html_src = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'index.html')
    with open(html_src, 'r') as f:
        html = f.read()
    html = html.replace('__API_URL__', api_url)
    s3.put_object(Bucket=bucket, Key='index.html', Body=html.encode(),
                  ContentType='text/html')
    ok("index.html uploaded")

    website_url = f"http://{bucket}.s3-website-{region}.amazonaws.com"
    print(f"""
╔══════════════════════════════════════════════════════════╗
║  ✅  Deployment complete!                               ║
╠══════════════════════════════════════════════════════════╣
║  Frontend : {website_url:<44} ║
║  API Base : {api_url:<44} ║
╚══════════════════════════════════════════════════════════╝
""")


# ── destroy ─────────────────────────────────────────────────────────────────────

def destroy(region: str, bucket: str):
    session = boto3.Session(region_name=region)
    iam  = session.client('iam')
    lmb  = session.client('lambda')
    apigw= session.client('apigateway')
    ddb  = session.client('dynamodb')
    s3   = session.client('s3')

    step("Deleting S3 bucket")
    try:
        objs = s3.list_objects_v2(Bucket=bucket).get('Contents', [])
        for o in objs:
            s3.delete_object(Bucket=bucket, Key=o['Key'])
        s3.delete_bucket(Bucket=bucket)
        ok(f"Bucket '{bucket}' deleted")
    except Exception as e:
        info(f"Skipped: {e}")

    step("Deleting API Gateway")
    try:
        apis = apigw.get_rest_apis()['items']
        api  = next((a for a in apis if a['name'] == 'FakeUserGateway'), None)
        if api:
            apigw.delete_rest_api(restApiId=api['id'])
            ok("API Gateway deleted")
    except Exception as e:
        info(f"Skipped: {e}")

    step("Deleting Lambda")
    try:
        lmb.delete_function(FunctionName='FakeUserAPI')
        ok("Lambda deleted")
    except Exception as e:
        info(f"Skipped: {e}")

    step("Detaching & deleting IAM role")
    try:
        for p in ['AWSLambdaBasicExecutionRole', 'AmazonDynamoDBFullAccess']:
            iam.detach_role_policy(RoleName='FakeUserLambdaRole',
                                   PolicyArn=f'arn:aws:iam::aws:policy/{p}')
        iam.delete_role(RoleName='FakeUserLambdaRole')
        ok("IAM role deleted")
    except Exception as e:
        info(f"Skipped: {e}")

    step("Deleting DynamoDB table")
    try:
        ddb.delete_table(TableName='UserProfiles')
        ok("Table deleted")
    except Exception as e:
        info(f"Skipped: {e}")

    print("\n  ✅  All resources removed.\n")


# ── entrypoint ──────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Deploy Fake-User Generator to AWS')
    parser.add_argument('--region', default='us-east-1')
    parser.add_argument('--bucket', required=True, help='Globally unique S3 bucket name')
    parser.add_argument('--destroy', action='store_true', help='Tear down all resources')
    args = parser.parse_args()

    if args.destroy:
        destroy(args.region, args.bucket)
    else:
        deploy(args.region, args.bucket)
