import json
import boto3
import uuid
from datetime import datetime
from decimal import Decimal
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'UserProfiles'

CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key',
    'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,DELETE'
}

def response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {**CORS_HEADERS, 'Content-Type': 'application/json'},
        'body': json.dumps(body, default=str)
    }

def lambda_handler(event, context):
    method = event.get('httpMethod', 'GET')
    path   = event.get('path', '/')

    # Preflight
    if method == 'OPTIONS':
        return response(200, {})

    table = dynamodb.Table(TABLE_NAME)

    # POST /users  – save a generated user
    if method == 'POST' and path == '/users':
        try:
            body = json.loads(event.get('body') or '{}')
            user_id = str(uuid.uuid4())
            item = {
                'userId':    user_id,
                'createdAt': datetime.utcnow().isoformat(),
                'firstName': body.get('firstName', ''),
                'lastName':  body.get('lastName', ''),
                'email':     body.get('email', ''),
                'phone':     body.get('phone', ''),
                'address':   body.get('address', ''),
                'city':      body.get('city', ''),
                'state':     body.get('state', ''),
                'zipCode':   body.get('zipCode', ''),
                'country':   body.get('country', ''),
                'company':   body.get('company', ''),
                'jobTitle':  body.get('jobTitle', ''),
                'username':  body.get('username', ''),
                'website':   body.get('website', ''),
                'bio':       body.get('bio', ''),
                'age':       body.get('age', 0),
                'gender':    body.get('gender', ''),
            }
            table.put_item(Item=item)
            return response(201, {'message': 'User saved successfully', 'userId': user_id, 'user': item})
        except Exception as e:
            return response(500, {'error': str(e)})

    # GET /users  – list all users
    if method == 'GET' and path == '/users':
        try:
            result = table.scan()
            users  = result.get('Items', [])
            # Sort newest first
            users.sort(key=lambda u: u.get('createdAt', ''), reverse=True)
            return response(200, {'users': users, 'count': len(users)})
        except Exception as e:
            return response(500, {'error': str(e)})

    # DELETE /users/{userId}
    if method == 'DELETE' and path.startswith('/users/'):
        try:
            user_id = path.split('/')[-1]
            table.delete_item(Key={'userId': user_id})
            return response(200, {'message': 'User deleted', 'userId': user_id})
        except Exception as e:
            return response(500, {'error': str(e)})

    return response(404, {'error': 'Route not found'})
